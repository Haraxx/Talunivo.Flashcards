# 50 überarbeitete Lernpakete für Talunivo

Brasilianisches Portugiesisch (`pt-BR`) mit deutschen Übersetzungen (`de`), für den Einstieg ohne Vorkenntnisse. Revision 4 enthält **428 Vokabelkarten in 50 Paketen**, mit 397 unterschiedlichen Wortpaaren. Jede Karte hat ein zweisprachiges Beispiel und einen deutschen Lernhinweis. Gleiche Wortpaare wiederholen sich bewusst in verwandten Themen und teilen ihren Wiederholungsstand.

Die Reihe ist ein Einstieg auf A0/A1-Niveau, kein vollständiger oder zertifizierter A1-Kurs. Einzelne Wörter und kurze Wendungen stehen auf der Vorderseite; die Beispielsätze zeigen ihren Gebrauch. Namen und Angaben kannst du beim freien Üben durch deine eigenen ersetzen.

Alle 50 Pakete verwenden jetzt Format 4 mit 50 Lernzielen und 1.468 expliziten Prüfungsaufgaben. Zehn Pakete haben Paketversion 5, 40 Paketversion 6. Die Karten bleiben gegenüber Revision 4 unverändert. Dafür ist eine App-Fassung mit Format-4-Unterstützung erforderlich; ältere App-Fassungen können diese Updates nicht importieren.

Die Lernziele beschreiben, welche gelernten Wendungen du übst. Die Prüfungen testen Erkennen, Auswählen und kontrolliertes Ergänzen. Freies Sprechen und freies Schreiben werden nicht geprüft.

## Einstieg und lokaler Import

1. Beginne mit Paket 01 und wenigen Karten pro Tag. Ein Paket enthält je nach Thema 8 bis 20 Karten.
2. Öffne **Pakete → Datei auswählen** und wähle eine `.talunivo`-Datei oder das vollständige Archiv `talunivo-start-ptbr-50.zip`.
3. Prüfe die validierte Vorschau einschließlich geänderter und ergänzter Karten. Erst **Paket importieren** beziehungsweise **Alle Pakete importieren** übernimmt die Inhalte.
4. Öffne **Lektion starten**. Bei längeren Paketen führen die Links **Teile dieses Lernpakets** zu allen Abschnitten. Jeder Abschnitt enthält höchstens acht Karten mit Beispielen und Bedeutungs-/Hörübungen.
5. Decke im Vokabeltraining die Lösung erst nach einem eigenen Versuch auf. Wiederhole fällige Wörter und passe das Tempo an dich an.
6. Zum freien Sprechen: Ersetze Namen, Zahlen, Uhrzeiten oder Orte in den Beispielen. Die letzten Pakete liefern Wortschatz für kleine Gesprächssituationen; die Vokabelkarten selbst sind kein zusammenhängender Dialog.

Importierte Inhalte und SQLite-Lernstände bleiben offline verfügbar. Für Offline-Audio muss eine lokale Stimme eingerichtet sein. Der ZIP-Import prüft alle Pakete gemeinsam und speichert sie erst nach Bestätigung; ein ungültiges Paket verhindert den gesamten Sammelimport.

Die 50 Paket-IDs und alle 428 Karten-IDs aus Version 3 bleiben erhalten. Revision 4 überarbeitet alle Beispiele und Lernhinweise nach einer unabhängigen KI-Sprachprüfung. Identische Wortpaare behalten ihren Wiederholungsstand. Die einzige Übersetzungsänderung betrifft estudar: lernen (Studium) wird zu lernen; studieren. Beim bestätigten Update von Paket 42 aus Version 3 übernimmt die aktuelle App dessen Wiederholungsstand gezielt. Verwende dafür eine App-Fassung mit dieser Migration. Bereits gelernte Zielstände bleiben erhalten. Bei Version 1 werden ersetzte Satzkarten mit ihrem bisherigen Fortschritt archiviert; dieser wird nicht auf mehrere neue Einzelwörter übertragen. Geänderte Lektionsteile erhalten einen eigenen Lektionsstand.

## Reihenfolge und Lernziele

| Nr. | Datei | Thema | Deine kleine Übung |
|---|---|---|---|
| 01 | [01-begruessung.talunivo](01-begruessung.talunivo) | Begrüßung und Abschied | Passende Begrüßungen und Abschiedsformeln im Tagesablauf verstehen und verwenden. |
| 02 | [02-vorstellung.talunivo](02-vorstellung.talunivo) | Name und Vorstellung | Nach Namen fragen und sich oder eine andere Person vorstellen. |
| 03 | [03-befinden.talunivo](03-befinden.talunivo) | Befinden und Gefühle | Nach dem Befinden fragen und einfache Angaben zu Wohlbefinden oder Müdigkeit verstehen und verwenden. |
| 04 | [04-hoeflichkeit.talunivo](04-hoeflichkeit.talunivo) | Bitte, danke, Entschuldigung | Sich passend bedanken, sich entschuldigen und höflich um etwas bitten. |
| 05 | [05-verstehen.talunivo](05-verstehen.talunivo) | Verstehen und Nachfragen | Bei Verständigungsproblemen gelernte Wendungen zum Nichtverstehen, zu Bedeutung und Schreibweise, zum Sprachenlernen und zu langsamerem Sprechen verstehen und passend auswählen. |
| 06 | [06-herkunft.talunivo](06-herkunft.talunivo) | Herkunft und Wohnort | Nach Herkunft und Wohnort fragen und passende Herkunfts- und Nationalitätsangaben verstehen. |
| 07 | [07-zahlen-zehn.talunivo](07-zahlen-zehn.talunivo) | Zahlen von null bis zehn | Zahlen bis zehn sowie einfache Mengen-, Personen- und Währungsangaben verstehen und passende Formen verwenden. |
| 08 | [08-zahlen-preise.talunivo](08-zahlen-preise.talunivo) | Zahlen und Preise bis hundert | Zahlen und einfache Preisangaben in Real verstehen und unterscheiden. |
| 09 | [09-uhrzeit.talunivo](09-uhrzeit.talunivo) | Uhrzeit und Verabredungen | Nach der Uhrzeit fragen und volle Stunden, Minuten und Tageszeiten unterscheiden. |
| 10 | [10-kalender.talunivo](10-kalender.talunivo) | Wochentage und Datum | Wochentage, einfache Datumsangaben und Geburtsmonate verstehen und nennen. |
| 11 | [11-familie.talunivo](11-familie.talunivo) | Familie und Menschen | Familienmitglieder benennen und einfache Aussagen über Verwandtschaft verstehen. |
| 12 | [12-alter-beruf.talunivo](12-alter-beruf.talunivo) | Alter und Beruf | Nach dem Alter fragen und einfache Angaben zu Alter, Beruf und Arbeitsort verstehen. |
| 13 | [13-wohnen.talunivo](13-wohnen.talunivo) | Zu Hause | Räume und Wohnformen benennen und einfache Angaben zum Wohnen verstehen. |
| 14 | [14-gegenstaende.talunivo](14-gegenstaende.talunivo) | Dinge im Alltag | Alltagsgegenstände benennen und nach ihrem Ort oder ihrer Zugehörigkeit fragen. |
| 15 | [15-farben.talunivo](15-farben.talunivo) | Farben und Beschreibungen | Farben und einfache Eigenschaften von Gegenständen verstehen und passend zu Nomen verwenden. |
| 16 | [16-fruehstueck.talunivo](16-fruehstueck.talunivo) | Frühstück | Lebensmittel beim Frühstück benennen und einfache Wünsche zu Speisen ausdrücken. |
| 17 | [17-getraenke.talunivo](17-getraenke.talunivo) | Getränke bestellen | Getränke bestellen und Zusätze wie Kohlensäure oder Eis unterscheiden. |
| 18 | [18-cafe.talunivo](18-cafe.talunivo) | Im Café | Im Café bestellen, nach der Karte fragen und die Rechnung erbitten. |
| 19 | [19-restaurant.talunivo](19-restaurant.talunivo) | Im Restaurant | Im Restaurant nach Gerichten und Zutaten fragen und einfache Bestellungen oder Wünsche äußern. |
| 20 | [20-supermarkt.talunivo](20-supermarkt.talunivo) | Im Supermarkt | Gelernte Fragen zu Waren, Verpackungen und Kasse verstehen sowie Mengen und Einkaufswünsche mit passenden Wendungen ausdrücken. |
| 21 | [21-obst-gemuese.talunivo](21-obst-gemuese.talunivo) | Obst und Gemüse | Obst und Gemüse unterscheiden und einfache Kaufwünsche formulieren. |
| 22 | [22-bezahlen.talunivo](22-bezahlen.talunivo) | Geld und Bezahlen | Nach dem Betrag fragen, Zahlungsarten nennen und um Wechselgeld oder einen Beleg bitten. |
| 23 | [23-kleidung.talunivo](23-kleidung.talunivo) | Kleidung und Größen | Kleidungsstücke benennen, nach Größen fragen und die Passform beschreiben. |
| 24 | [24-stadt.talunivo](24-stadt.talunivo) | Orte in der Stadt | Orte in der Stadt benennen und einfache Angaben zu Lage und Entfernung sowie dazu, ob Orte geöffnet oder geschlossen sind, verstehen. |
| 25 | [25-wegbeschreibung.talunivo](25-wegbeschreibung.talunivo) | Nach dem Weg fragen | Nach dem Weg fragen und einfache Richtungs- und Lageangaben verstehen. |
| 26 | [26-bus-metro.talunivo](26-bus-metro.talunivo) | Bus und Metro | Nach Fahrkarten, Linien und Haltestellen fragen und einfache Angaben zum Umsteigen verstehen. |
| 27 | [27-taxi.talunivo](27-taxi.talunivo) | Mit dem Taxi unterwegs | Gelernte Wendungen zu Fahrtzielen und Adressen sowie einfache Fragen während einer Taxifahrt verstehen und passend auswählen. |
| 28 | [28-hotel.talunivo](28-hotel.talunivo) | Ankunft im Hotel | Bei der Ankunft im Hotel Angaben zu Reservierung, Zimmer und Aufenthalt verstehen und erfragen. |
| 29 | [29-hotel-hilfe.talunivo](29-hotel-hilfe.talunivo) | Kleine Probleme im Hotel | Im Hotel um fehlende Dinge oder Hilfe bei einfachen Zimmerproblemen bitten. |
| 30 | [30-tagesablauf.talunivo](30-tagesablauf.talunivo) | Mein Tagesablauf | Einfache Tätigkeiten im Tagesablauf benennen und zeitlich einordnen. |
| 31 | [31-haushalt.talunivo](31-haushalt.talunivo) | Im Haushalt | Einfache Haushaltstätigkeiten verstehen und Gegenstände beim Aufräumen oder Reinigen benennen. |
| 32 | [32-vorlieben.talunivo](32-vorlieben.talunivo) | Was ich mag | Vorlieben und Interessen mit einfachen Ausdrücken benennen und erfragen. |
| 33 | [33-freizeit.talunivo](33-freizeit.talunivo) | Freizeit und Hobbys | Einfache Freizeitaktivitäten benennen und entsprechende Aussagen verstehen. |
| 34 | [34-einladen.talunivo](34-einladen.talunivo) | Einladen und Verabreden | Eine Einladung verstehen, gemeinsame Unternehmungen vorschlagen und auf Vorschläge reagieren. |
| 35 | [35-wetter.talunivo](35-wetter.talunivo) | Wetter und Jahreszeiten | Einfache Angaben zu Wetter, Temperaturen und Jahreszeiten verstehen und unterscheiden. |
| 36 | [36-strand.talunivo](36-strand.talunivo) | Strand und Ausflug | Dinge am Strand benennen und einfache Wünsche oder Beschreibungen verstehen. |
| 37 | [37-koerper.talunivo](37-koerper.talunivo) | Körper und Befinden | Körperteile benennen und ihre gelernten Einzahl- und Mehrzahlformen unterscheiden. |
| 38 | [38-beduerfnisse.talunivo](38-beduerfnisse.talunivo) | Hunger, Durst und Bedürfnisse | Grundlegende Bedürfnisse wie Hunger, Durst oder Ruhe ausdrücken und verstehen. |
| 39 | [39-apotheke.talunivo](39-apotheke.talunivo) | In der Apotheke | Gelernte Wörter und Wendungen zu Rezept, Anweisungen und Hilfe in der Apotheke verstehen und passende Bitten um Informationen auswählen. |
| 40 | [40-hilfe.talunivo](40-hilfe.talunivo) | Um Hilfe bitten | Um Hilfe bitten und einfache Angaben zu Orientierung oder Problemen verstehen. |
| 41 | [41-handy.talunivo](41-handy.talunivo) | Handy und Kontakt | Einfache Angaben zu Telefonnummer, Nachrichten und Handynutzung verstehen. |
| 42 | [42-lernen.talunivo](42-lernen.talunivo) | Lernen und Üben | Gelernte Fragen und Wendungen zu Beispielen, Wortschatz, Aussprache, Üben und Verstehen erkennen und passend auswählen. |
| 43 | [43-koennen.talunivo](43-koennen.talunivo) | Können und Erlaubnis | Einfache Möglichkeiten, Fähigkeiten und Bitten mit den gelernten Ausdrücken verstehen. |
| 44 | [44-vergleichen.talunivo](44-vergleichen.talunivo) | Einfach vergleichen | Einfache Vergleiche zu Menge, Größe, Preis oder Entfernung verstehen und unterscheiden. |
| 45 | [45-plaene.talunivo](45-plaene.talunivo) | Pläne für morgen | Einfache Pläne für spätere Aktivitäten verstehen und ausdrücken. |
| 46 | [46-gestern.talunivo](46-gestern.talunivo) | Von gestern erzählen | Einfache Aussagen über gestern und vergangene Tätigkeiten oder Zeitspannen verstehen. |
| 47 | [47-gespraech.talunivo](47-gespraech.talunivo) | Kleine Gespräche verbinden | Kurze Aussagen mit gelernten Verbindungswörtern verbinden und einfache Gesprächsreaktionen verstehen. |
| 48 | [48-mission-markt.talunivo](48-mission-markt.talunivo) | Mini-Dialog: Auf dem Markt | Beim Einkauf auf dem Markt nach Waren und Preisen fragen und Mengen oder Wünsche nennen. |
| 49 | [49-mission-verabredung.talunivo](49-mission-verabredung.talunivo) | Mini-Dialog: Einen Ausflug planen | Einen Ausflug oder ein Treffen mit Zeit, Ort und gemeinsamen Aktivitäten planen. |
| 50 | [50-mission-alltag.talunivo](50-mission-alltag.talunivo) | Abschluss: Ein Tag in Brasilien | Einfache Angaben zu Begegnungen, Essen und Unternehmungen an einem Tag in Brasilien verstehen. |

## Format und Prüfung

Alle Dateien sind UTF-8-JSON im Vokabelformat `schemaVersion: 4`, mit `packageVersion: 5` (zehn Pakete) oder `6` (40 Pakete). Die Paketversion ist unabhängig von der Formatversion. Bei Änderungen vorhandener Karten wird die Paketversion erhöht; eine neue Paket-ID ist dafür nicht erforderlich. Jede Karte verwendet `isVocabulary: true`.

Die Zahlen null bis zehn haben jeweils ein eigenes Anwendungsbeispiel. Zahlen elf bis neunzehn und die Zehner bis hundert, alle sieben Wochentage sowie alle vier Jahreszeiten sind vollständig vertreten. Hinweise erklären unter anderem Genus, Plural, Zeitformen, brasilianische Varianten und mehrdeutige Wörter.

Der echte App-Parser, der Katalog und SHA-256-Prüfsummen werden über `tools/Talunivo.PackageValidator` geprüft. Die Tests prüfen Vollständigkeit, alle 59 Lektionsteile, Vorschau, Import, Neustart, Reimport und Updates aus den archivierten Versionen 1 und 2. Die UI-Tests zeigen sämtliche Teile in `classic`, `sunny` und `street` an.

```powershell
dotnet run --project tools/Talunivo.PackageValidator -- docs/lernpakete --audit
dotnet test Talunivo.Tests/Talunivo.Tests.csproj
dotnet test Talunivo.UiTests/Talunivo.UiTests.csproj
```

Die Originaldateien liegen im App-Repository unter `docs/content/archive/learning-packages-before-revision-3.zip`. Der redaktionelle Änderungsnachweis enthält für jede Karte Vorher-/Nachher-Daten und Referenzprüfsummen. Eine unabhängige muttersprachliche Prüfung und ein Import auf deinem Android-Gerät sind nicht erfolgt. Es wurde nichts veröffentlicht oder automatisch importiert.
